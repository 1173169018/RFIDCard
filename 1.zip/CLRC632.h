#ifndef _CLRC632_H
#define _CLRC632_H


#define uchar unsigned char
#define uint unsigned  int
#define COMMAND_NONSURPORT  0xF1						   //��֧������
#define ERROR				0xFE						   //��������
#define TRUE  				0x01
#define FALSE				0x00


uint ConverByteTOASCII(unsigned char Src);
uchar ConverTwoAsciiByteToHex( uchar *Pstart);
void Rc500Ready(void);
void ComHandshakeWithPC(void);
void SendByte(unsigned char i);
void SendStr(unsigned char *Str,unsigned char StrLenth);

#endif

