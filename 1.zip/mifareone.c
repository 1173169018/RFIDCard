#include <string.h>
#include "stm32f10x_gpio.h"
#include "rc500.h"


#define CARD_15693          0X03						   //��15693�Ŀ�
extern unsigned char CardType;                             //��ǰ�������� 
extern void GPIOSetValue( unsigned int portNum, unsigned int bitPosi, unsigned int bitVal );
extern unsigned int GPIOGetValue( unsigned int portNum, unsigned int bitPosi);
extern	unsigned char MFoutValue;
extern	unsigned char TestAnaValue;
extern	unsigned char TestDigiValue;
/*****************************************************************************
         ��ʱ
*****************************************************************************/
void DelayMs(uchar j)
{

	uchar i,n;
   	for(i=0;i<j;i++)
   	  {   
   		for(n=0;n<230;n++);
   	  }
}
void DelayUs(uchar j)
{
	uchar i,n;
	n=j/5;
	for(i=0;i<n;i++);
}

/*****************************************************************************
*ԭ�ͣ�uchar ReadRawRC(uchar Address)
*���ܣ���RC500�Ĵ���
*      �üĴ������ڵ�ǰҳ��
*input:Address=�Ĵ�����ַ
*ouput:������ֵ
******************************************************************************/
uchar ReadRawRC(uchar cAddress)
{
	unsigned char cValue = MI_OK;
	unsigned char cCounter;

	RC530_MOSI_L;
	cAddress <<= 1;
	cAddress |=  0x80;
	cAddress &=  0xFE;
	RC530_CLK_L;
	RC530_NSS_L;
	for (cCounter=0; cCounter<8; cCounter++)
	{
		(cAddress & 0x80) ? RC530_MOSI_H : RC530_MOSI_L;
		RC530_CLK_H;
		cAddress <<= 1;
		RC530_CLK_L;
	}
	RC530_MOSI_L;
	for (cCounter=0;cCounter<8;cCounter++)
	{ 
		cValue <<= 1;  
		RC530_CLK_H;
		cValue |= (RC530_MISO) ? 1 : 0;
		RC530_CLK_L;					     
	}
	RC530_CLK_L;
	RC530_NSS_H; 
	return (cValue);
}

/*****************************************************************************
*ԭ�ͣ�uchar ReadRC(uchar Address)
*���ܣ���RC500�Ĵ���
*input:Address=�Ĵ�����ַ
*ouput:������ֵ
******************************************************************************/
uchar ReadRC(uchar cAddress)
{
	WriteRawRC(0x00, (0x80 | (cAddress>>3))); // select appropriate page	
    return ReadRawRC(cAddress);               // read value at the specified address 
}


/*****************************************************************************
*ԭ�ͣ�void WriteRawRC(uchar Address,uchar value)
*���ܣ�дRC500�Ĵ���
*      �üĴ������ڵ�ǰҳ��
*input:Address=�Ĵ�����ַ
*      value=Ҫд���ֵ
*ouput:��
******************************************************************************/
void WriteRawRC(uchar cAddress, uchar cValue)
{
	unsigned char cCounter;
	
	RC530_MOSI_L;
	cAddress <<= 1;
	cAddress &= 0x7E;
	RC530_CLK_L;
	RC530_NSS_L;
	for (cCounter=0; cCounter<8; cCounter++)
	{
		(cAddress & 0x80) ? RC530_MOSI_H : RC530_MOSI_L;
		RC530_CLK_H;//=	1;
		cAddress	<<=	1;
		RC530_CLK_L;//=	0;
	}

	for (cCounter=0; cCounter<8; cCounter++)
 	{
		(cValue & 0x80) ? RC530_MOSI_H : RC530_MOSI_L;
		RC530_CLK_H;
		cValue <<= 1;
		RC530_CLK_L;
	}
	RC530_CLK_L;
	RC530_MOSI_L;
	RC530_NSS_H;
}
/*****************************************************************************
*ԭ�ͣ�void WriteRC(uchar Address,uchar value)
*���ܣ�дRC500�Ĵ���
*input:Address=�Ĵ�����ַ
*      value=Ҫд���ֵ
*ouput:��
******************************************************************************/
void WriteRC(unsigned char cAddress, unsigned char cValue)
{
	WriteRawRC(0x00, (0x80 | (cAddress>>3))); // select appropriate page 
	WriteRawRC(cAddress,cValue); //write value at the specified address                                      
}

/*****************************************************************************
*ԭ�ͣ�void SetBitMask(uchar reg,uchar mask)
*���ܣ���RC500�Ĵ���λ
*input:reg=�Ĵ�����ַ
*      mask=��λֵ
*output:��
*****************************************************************************/
void SetBitMask(uchar reg,uchar mask)
{
   char tmp=0x0;
   
   tmp=ReadRC(reg);
   WriteRC(reg,tmp|mask);
}
/*****************************************************************************
*ԭ�ͣ�void ClearBitMask(uchar reg,uchar mask)
*���ܣ���RC500�Ĵ���λ
*input:reg=�Ĵ�����ַ
*      mask=��λֵ
*output:��
*****************************************************************************/
void ClearBitMask(uchar reg,uchar mask)
{
   char tmp=0x0;
   tmp = ReadRC(reg);
   WriteRC(reg,tmp & ~mask);
}
/*****************************************************************************
*ԭ�ͣ�signed char PcdAnticoll(uchar *snr)
*���ܣ�����ײ
*      Ѱ���ɹ���ͨ���˺������������ڿ�Ƭ���ͷ���ײ����������������м��ſ�
*      �˺���ֻ�õ�һ�ſ�Ƭ�����кţ�����Pcdselect()����ѡ�����ſ��������к���
*      ������Դ˿���������Ϻ���PcdHalt()����˿���������״̬����Ѱδ��������
*      ״̬�Ŀ����ɽ���������Ƭ�Ĳ���
*input:snr=������к�(4byte)���ڴ浥Ԫ�׵�ַ
*output:status=MI_OK:�ɹ�
*       �õ������кŷ���ָ����Ԫ
*****************************************************************************/
signed char PcdAnticoll(uchar *snr)
{
    uchar i;
    uchar snr_check=0;
    signed char status=MI_OK;
	TranSciveBuffer MfComData;
    TranSciveBuffer * pi;

    pi=&MfComData;
    PcdSetTmo(106);
    WriteRC(RegDecoderControl,0x28);
    ClearBitMask(RegControl,0x08);
    WriteRC(RegChannelRedundancy,0x03);

    MfComData.MfCommand=PCD_TRANSCEIVE;
    MfComData.MfLength=2;
    MfComData.MfData[0]=PICC_ANTICOLL1;
    MfComData.MfData[1]=0x20;
    status=PcdComTransceive(pi);
    if(!status)
    {
    	 for(i=0;i<4;i++)
         {
             snr_check^=MfComData.MfData[i];
         }
         if(snr_check!=MfComData.MfData[i])
         {
             status=MI_SERNRERR;
         }
         else
         {
             for(i=0;i<4;i++)
             {
             	*(snr+i)=MfComData.MfData[i];
             }
         }

    }
    ClearBitMask(RegDecoderControl,0x20);
    return status;
}
/*****************************************************************************
*ԭ�ͣ�signed char PcdAuthKey(uchar *keys)
*���ܣ�����ת����ʽ�����Կ�͵�RC500��FIFO��
*input:keys=12�ֽ���Կ����׵�ַ
*output:status=MI_OK:�ɹ�
*****************************************************************************/
signed char PcdAuthKey(uchar *keys)
{
    signed char status;
    uchar i;
	TranSciveBuffer MfComData;
    TranSciveBuffer *pi;
	
    pi=&MfComData;
    PcdSetTmo(4);
    MfComData.MfCommand=PCD_LOADKEY;
    MfComData.MfLength=12;
    for(i=0;i<12;i++)
    {
        MfComData.MfData[i]=*(keys+i);
    }
    status=PcdComTransceive(pi);
    return status;
}

/*****************************************************************************
*ԭ�ͣ�signed char PcdAuthState(uchar auth_mode,uchar block,uchar *snr)
*���ܣ��ô��RC500��FIFO�е���Կ�Ϳ��ϵ���Կ������֤
*input:auth_mode=��֤��ʽ,0x60:��֤A��Կ,0x61:��֤B��Կ
*      block=Ҫ��֤�ľ��Կ��
*      snr=���к��׵�ַ
*output:status=MI_OK:�ɹ�
*****************************************************************************/
signed char PcdAuthState(uchar auth_mode,uchar block,uchar *snr)
{
    signed char status=MI_OK;
    uchar i;
	TranSciveBuffer MfComData;
    TranSciveBuffer *pi;
	
    pi=&MfComData;
    if(status==MI_OK)
    {	PcdSetTmo(4);
        MfComData.MfCommand=PCD_AUTHENT1;
        MfComData.MfLength=6;
        MfComData.MfData[0]=auth_mode;
        MfComData.MfData[1]=block;
        for(i=0;i<4;i++)
        {
	      MfComData.MfData[i+2]=*(snr+i);
        }
        if((status=PcdComTransceive(pi))==MI_OK)
        {
            if (ReadRC(RegSecondaryStatus)&0x07) 
             {
                status = MI_BITCOUNTERR;
             }
            else
            {
                MfComData.MfCommand=PCD_AUTHENT2;
                MfComData.MfLength=0;
                if((status=PcdComTransceive(pi))==MI_OK)
                {
                    if(ReadRC(RegControl)&0x08)
                        status=MI_OK;
                    else
                        status=MI_AUTHERR;
                }
             }
         }
   }
   return status;
}
/*****************************************************************************
*ԭ�ͣ�signed char PcdComTransceive(TranSciveBuffer *pi)
*���ܣ���RC500ͨѶ
*input:pi->MfCommand=RC500������
*      pi->MfLength=���͵����ݳ���
*      pi->MfData[]=��������
*output:status=������
*       pi->MfLength=���յ����ݳ���
*       pi->MfData[]=��������
*****************************************************************************/

signed char PcdComTransceive(TranSciveBuffer *pi)
{
   uchar recebyte=0;
   signed char status = MI_OK;
   uchar irqEn=0x00;
   uchar waitFor=0x00;
   uchar lastBits;
   uchar n;
   uint i;

   switch(pi->MfCommand)
   {
      case PCD_IDLE:
         irqEn = 0x00;
         waitFor = 0x00;
         break;
      case PCD_WRITEE2:
         irqEn = 0x11;
         waitFor = 0x10;
         break;
      case PCD_READE2:
         irqEn = 0x07;
         waitFor = 0x04;
         recebyte=1;
         break;
      case PCD_LOADCONFIG:
      case PCD_LOADKEYE2:
      case PCD_AUTHENT1:
         irqEn = 0x05;
         waitFor = 0x04;
         break;
      case PCD_CALCCRC:
         irqEn = 0x11;
         waitFor = 0x10;
         break;
      case PCD_AUTHENT2:
         irqEn = 0x04;
         waitFor = 0x04;
         break;
      case PCD_RECEIVE:
         irqEn = 0x06;
         waitFor = 0x04;
         recebyte=1;
         break;
      case PCD_LOADKEY:
         irqEn = 0x05;
         waitFor = 0x04;
         break;
      case PCD_TRANSMIT:
         irqEn = 0x05;
         waitFor = 0x04;
         break;
      case PCD_TRANSCEIVE:
         irqEn = 0x3D;
         waitFor = 0x04;
         recebyte=1;
         break;
      default:
         pi->MfCommand=PCD_UNKNOWN_COMMAND;
         break;
   }
   if(pi->MfCommand!=PCD_UNKNOWN_COMMAND)
   {
      WriteRC(RegPage,0x00);
      WriteRC(RegInterruptEn,0x7F);
      WriteRC(RegInterruptRq,0x7F);
      WriteRC(RegCommand,PCD_IDLE);
      SetBitMask(RegControl,0x01);
      WriteRC(RegInterruptEn,irqEn|0x80);
      for(i=0;i<pi->MfLength;i++)
      {
         WriteRC(RegFIFOData,pi->MfData[i]);
      }
      WriteRC(RegCommand,pi->MfCommand);
      i=0x2000;
      do
      {
         n=ReadRC(RegInterruptRq);
         i--;
      }
      while((i!=0)&&!(n&irqEn&0x20)&&!(n&waitFor));	//timeout || idle
      status=MI_COM_ERR;
      if((i!=0)&&!(n&irqEn&0x20))
      {
      	n = ReadRC(0x0B);			//����ײλ��
		n = ReadRC(RegErrorFlag);
		 if(!(n & 0x17))
         {
            status=MI_OK;
            if(recebyte)
            {
              	n=ReadRC(RegFIFOLength);
              	lastBits=ReadRC(RegSecondaryStatus)&0x07;
                if(lastBits)
                {
                   pi->MfLength=(n-1)*8+lastBits;
                }
                else
                {
                   pi->MfLength=n*8;
                }
                if(n==0)
                {
                   n=1;
                }
                for(i=0;i<n;i++)
                {
                   pi->MfData[i]=ReadRC(RegFIFOData);
                }
            }
         }
    	  else if (n & 0x01)			//����ײ
	  	 {
		 	status = MI_COLLERR;
            if(recebyte)
            {
              	n=ReadRawRC(RegFIFOLength);
              	lastBits=ReadRawRC(RegSecondaryStatus)&0x07;
                if(lastBits)
                {
                   pi->MfLength=(n-1)*8+lastBits;
                }
                else
                {
                   pi->MfLength=(n+1)*8;
                }
                if(n==0)
                {
                   n=1;
                }
                for(i=0;i<n;i++)
                {
                      pi->MfData[i+1]=ReadRawRC(RegFIFOData);
                }
            }
			pi->MfData[0]=ReadRawRC(0x0B);
		 }
		 else if (n & 0x02)	      //��ż�������
		 {
		 	status = MI_PARITYERR;
            if(recebyte)
            {
              	n=ReadRawRC(RegFIFOLength);
              	lastBits=ReadRawRC(RegSecondaryStatus)&0x07;
                if(lastBits)
                {	
                	pi->MfLength=(n-1)*8+lastBits;
                }
                else
                {
                	pi->MfLength=(n+1)*8;
                }
                if(n==0)
                {
                	n=1;
                }
                for(i=0;i<n;i++)
                {
                	pi->MfData[i]=ReadRawRC(RegFIFOData);
                }
            }
		 }
      }
      else if(n&irqEn&0x20)//timeout
      {
          status=MI_NOTAGERR;
      }
      else
      {
          status=MI_COM_ERR;
      }
      WriteRC(RegInterruptEn,0x7F);
      WriteRC(RegInterruptRq,0x7F);
	  SetBitMask(RegControl,0x04); 
      WriteRC(RegCommand,PCD_IDLE); 
	}

	return status;
}
/*****************************************************************************
*ԭ�ͣ�signed char PcdRead(uchar addr,uchar *readdata)
*���ܣ�������һ��(block)����(16�ֽ�)
*input:adde=Ҫ���ľ��Կ��
*      readdata=���������ݴ���׵�ַ
*output:status=MI_OK:�ɹ�
*       ���������ݴ���readdataָ��ĵ�Ԫ
*****************************************************************************/
signed char PcdRead(uchar addr,uchar *readdata)
{
    signed char status;
    uchar i;
    TranSciveBuffer MfComData;
    TranSciveBuffer *pi;

    pi=&MfComData;
    PcdSetTmo(4);
    WriteRC(RegChannelRedundancy,0x0F);
    MfComData.MfCommand=PCD_TRANSCEIVE;
    MfComData.MfLength=2;
    MfComData.MfData[0]=PICC_READ;
    MfComData.MfData[1]=addr;

    status=PcdComTransceive(pi);
    if(status==MI_OK)
    {
        if(MfComData.MfLength!=0x80)
        {
            status = MI_BITCOUNTERR;
        }
        else
        {
            for(i=0;i<16;i++)
            {
                *(readdata+i)=MfComData.MfData[i];
            }
        }
    }
    return status;
}
/*****************************************************************************
*ԭ�ͣ�signed char PcdWrite(uchar addr,uchar *writedata)
*���ܣ�д���ݵ����ϵ�һ��
*input:adde=Ҫд�ľ��Կ��
*      writedata=д�������׵�ַ
*output:status=MI_OK:�ɹ�
*****************************************************************************/
signed char PcdWrite(uchar addr,uchar *writedata)
{
    signed char status;
    uchar i;
	TranSciveBuffer MfComData;
    TranSciveBuffer *pi;
    pi=&MfComData;

    WriteRawRC(RegChannelRedundancy,0x0f); 
    MfComData.MfCommand = PCD_TRANSCEIVE;
    MfComData.MfLength  = 2;
    MfComData.MfData[0] = PICC_WRITE;
    MfComData.MfData[1] = addr;

    status=PcdComTransceive(pi);
    if(status!=MI_NOTAGERR)
    {
        if(MfComData.MfLength!=4)
        {
           status=MI_BITCOUNTERR;
        }
        else
        {
           MfComData.MfData[0]&=0x0f;
           switch(MfComData.MfData[0])
           {
              case 0x00:
                 status=MI_NOTAUTHERR;
                 break;
              case 0x0a:
                 status=MI_OK;
                 break;
              default:
                 status=MI_CODEERR;
                 break;
           }
        }
     }
     if(status==MI_OK)
     {
        PcdSetTmo(15);
        MfComData.MfCommand = PCD_TRANSCEIVE;
        MfComData.MfLength  = 16;
        for(i=0;i<16;i++)
        {
            MfComData.MfData[i]=*(writedata+i);
        }
        status=PcdComTransceive(pi);
        if(status!=MI_NOTAGERR)
        {
            MfComData.MfData[0]&=0x0f;
            switch(MfComData.MfData[0])
            {
               case 0x00:
                  status=MI_WRITEERR;
                  break;
               case 0x0a:
                  status=MI_OK;
                  break;
               default:
                  status=MI_CODEERR;
                  break;
           }
        }
		              PcdSetTmo(106);


     }
  return status;
}/*****************************************************************************
*ԭ�ͣ�signed char PcdRequest(uchar req_code)
*���ܣ�Ѱ��
*input:req_code=Ѱ����ʽ
*      req_code=0x52:Ѱ�����������з���14443A��׼�Ŀ�
*      req_code=0x26:ֻѰδ��������״̬�Ŀ�
*ouput:status=MI_OK:Ѱ���ɹ�
*****************************************************************************/
signed char PcdRequest(uchar req_code)
{
   signed char status;
   TranSciveBuffer MfComData;
   TranSciveBuffer *pi;

   pi=&MfComData;
   PcdSetTmo(106);
   WriteRC(RegChannelRedundancy,0x03);
   ClearBitMask(RegControl,0x08);
   WriteRC(RegBitFraming,0x07);
   MfComData.MfCommand=PCD_TRANSCEIVE;
   MfComData.MfLength=1;
   MfComData.MfData[0]=req_code;
   status=PcdComTransceive(pi);
   if(!status)
   {    if(MfComData.MfLength!=0x10)
        {
         status=MI_BITCOUNTERR;
        }
   }
   return status;
}

/*****************************************************************************
*ԭ�ͣ�signed char PcdSelect(uchar *snr)
*���ܣ�ѡ��һ�ſ�
*input:snr=������к�(4byte)���ڴ浥Ԫ�׵�ַ
*output:status=MI_OK:�ɹ�
*****************************************************************************/

signed char PcdSelect(uchar *snr)
{
    uchar i;
    signed char status;
    uchar snr_check=0;
	TranSciveBuffer MfComData;
    TranSciveBuffer *pi;

    pi=&MfComData;
    PcdSetTmo(106);
    WriteRC(RegChannelRedundancy,0x0F);
    ClearBitMask(RegControl,0x08);

    MfComData.MfCommand=PCD_TRANSCEIVE;
    MfComData.MfLength=7;
    MfComData.MfData[0]=PICC_ANTICOLL1;
    MfComData.MfData[1]=0x70;
    for(i=0;i<4;i++)
    {
    	snr_check^=*(snr+i);
    	MfComData.MfData[i+2]=*(snr+i);
    }
    MfComData.MfData[6]=snr_check;
    status=PcdComTransceive(pi);
    if(status==MI_OK)
    {    if(MfComData.MfLength!=0x8)
        {
         status = MI_BITCOUNTERR;
        }
   }
   return status;
}
/*****************************************************************************
*                ����RC500��ʱ��
*****************************************************************************/

void PcdSetTmo(unsigned char tmoLength)
{
	switch(tmoLength)
	{  
		case 1:                         // (0.604 ms) FWI=1
		WriteRawRC(RegTimerClock,0x07); // TAutoRestart=0,TPrescale=128
		WriteRawRC(RegTimerReload,0x41);// TReloadVal = 'h41 =65(dec) 
		break;
		case 2:                         // (1.208 ms) FWI=2
		WriteRawRC(RegTimerClock,0x07); // TAutoRestart=0,TPrescale=128
		WriteRawRC(RegTimerReload,0x81);// TReloadVal = 'h81 =129(dec) 
		break;
		case 3:                         // (2.416 ms) FWI=3
		WriteRawRC(RegTimerClock,0x09); // TAutoRestart=0,TPrescale=4*128
		WriteRawRC(RegTimerReload,0x41);// TReloadVal = 'h41 =65(dec) 
		break;
		case 4:                         // (4.833 ms) FWI=4
		WriteRawRC(RegTimerClock,0x09); // TAutoRestart=0,TPrescale=4*128
		WriteRawRC(RegTimerReload,0xFF);//81);// TReloadVal = 'h81 =129(dec) 
		break;
		case 5:                         // (9.666 ms) FWI=5
		WriteRawRC(RegTimerClock,0x0B); // TAutoRestart=0,TPrescale=16*128
		WriteRawRC(RegTimerReload,0x41);// TReloadVal = 'h41 =65(dec) 
		break;
		case 6:                         // (19.33 ms) FWI=6
		WriteRawRC(RegTimerClock,0x0B); // TAutoRestart=0,TPrescale=16*128
		WriteRawRC(RegTimerReload,0x81);// TReloadVal = 'h81 =129(dec) 
		break;
		case 7:                         // (38.66 ms) FWI=7
		WriteRawRC(RegTimerClock,0x0D); // TAutoRestart=0,TPrescale=64*128
		WriteRawRC(RegTimerReload,0x41);// TReloadVal = 'h41 =65(dec) 
		break;
		case 8:                         // (77.32 ms) FWI=8
		WriteRawRC(RegTimerClock,0x0D); // TAutoRestart=0,TPrescale=64*128
		WriteRawRC(RegTimerReload,0x81);// TReloadVal = 'h81 =129(dec) 
		break;
		case 9:                         // (154.6 ms) FWI=9
		WriteRawRC(RegTimerClock,0x0F); // TAutoRestart=0,TPrescale=256*128
		WriteRawRC(RegTimerReload,0x41);// TReloadVal = 'h41 =65(dec) 
		break;
		case 10:                        // (309.3 ms) FWI=10
		WriteRawRC(RegTimerClock,0x0F); // TAutoRestart=0,TPrescale=256*128
		WriteRawRC(RegTimerReload,0x81);// TReloadVal = 'h81 =129(dec) 
		break;
		case 11:                        // (618.6 ms) FWI=11
		WriteRawRC(RegTimerClock,0x13); // TAutoRestart=0,TPrescale=4096*128
		WriteRawRC(RegTimerReload,0x11);// TReloadVal = 'h21 =17(dec) 
		break;
		case 12:                        // (1.2371 s) FWI=12
		WriteRawRC(RegTimerClock,0x13); // TAutoRestart=0,TPrescale=4096*128
		WriteRawRC(RegTimerReload,0x21);// TReloadVal = 'h41 =33(dec) 
		break;
		case 13:                        // (2.4742 s) FWI=13
		WriteRawRC(RegTimerClock,0x13); // TAutoRestart=0,TPrescale=4096*128
		WriteRawRC(RegTimerReload,0x41);// TReloadVal = 'h81 =65(dec) 
		break;
		case 14:                        // (4.9485 s) FWI=14
		WriteRawRC(RegTimerClock,0x13); // TAutoRestart=0,TPrescale=4096*128
		WriteRawRC(RegTimerReload,0x81);// TReloadVal = 'h81 =129(dec) 
		break;
		case 15:                        // (4.9485 s) FWI=14
		WriteRawRC(RegTimerClock,0x9); // TAutoRestart=0,TPrescale=4096*128
		WriteRawRC(RegTimerReload,0x0ff);// TReloadVal = 'h81 =129(dec) 
		break;		
		default:                             // short timeout (1,0 ms)
		WriteRC(RegTimerClock,0x19);      // TAutoRestart=0,TPrescale=128
		WriteRC(RegTimerReload,tmoLength);// TReloadVal = tmoLength
		break;

	}
	WriteRC(RegTimerControl,0X06);
			  
}

char PcdAntennaOn()
{
    unsigned char i;
    i = ReadRawRC(RegTxControl);
    if (i & 0x03)
    {   return MI_OK;	}
    else
    {
        SetBitMask(RegTxControl, 0x03);
        return MI_OK;
    }
}

/*****************************************************************************
*          ��λ����ʼ��RC500
*ע��:RC500�ϵ��Ӧ��ʱ500ms���ܿɿ���ʼ��
******************************************************************************/
signed char PcdReset()
{
	signed char status = MI_OK;
	unsigned char n;

	unsigned int i = 0x1000;

	RC530_RST_H;
	DelayMs(200);
	RC530_RST_L;
	do {
		n = ReadRawRC(RegCommand);		    //��command�Ĵ��� bit7 = 0 �ӿڵ��߼����ɹ� 											//bit7=1�ӿڵ��߼���� ���ڽ��� bit5~bit0 reading����ִ��ʲô����
		i--;
	} while (0 != i && 0x00 != n);
	if (0 != i)
	 {
			if(CardType == CARD_15693)
			  {	
				 	WriteRC(RegClockQControl,0x0);
					WriteRC(RegClockQControl,0x40);
				  
					WriteRC(RegTestAnaSelect, TestAnaValue);	  //Analog Test 2013-6-20-11-00�޸�
					WriteRC(RegTestDigiSelect,TestDigiValue);	  //Digtal Test:data received from the card   --2013-6-20-11-00�޸�	

					DelayUs(100);
					ClearBitMask(RegClockQControl,0x40);  
			  }
			 else
			 {}
 	 }
	else
	{
		status = MI_RESETERR;
	}
	return status;
}
/*****************************************************************************
*ԭ�ͣ�signed char ChangeCodeKey(uchar *uncoded,uchar *coded)
*���ܣ�����Կת��ΪRC500���ո�ʽ
*input:uncoded=6�ֽ�δת������Կ�׵�ַ
*      coded=12�ֽ�ת�������Կ����׵�ַ
*output:status=MI_OK:�ɹ�
*       ת�������Կ����ָ����Ԫ
*****************************************************************************/
signed char ChangeCodeKey(uchar *uncoded,uchar *coded)
{
   uchar  cnt=0;
   uchar  ln=0;
   uchar  hn=0;

   for(cnt=0;cnt<6;cnt++)
   {
      ln=uncoded[cnt]&0x0F;
      hn=uncoded[cnt]>>4;
      coded[cnt*2+1]=(~ln<<4)|ln;
      coded[cnt*2]=(~hn<<4)|hn;
   }
   return MI_OK;
}

///////////////////////////////////////////////////////////////////////
//          C O N F I G   I S O 1 5 6 9 3   T Y P E 
///////////////////////////////////////////////////////////////////////
char M500PcdConfigISO15693()
{
		ClearBitMask(RegControl,0x08); 		    //ȡ�����ݴ������

		//page2
		WriteRawRC(RegPage, 0x82);
		WriteRawRC(RegTxControl, 0x5B);				//	RegTxControl
		WriteRawRC(RegCwConductance, 0x3F);			//	RegCwConductance
		WriteRawRC(RegModConductance, 0x3F);		//	RegModConductance
		WriteRawRC(RegCoderControl, 0x2F);			//	RegCoderControl
		WriteRawRC(RegModWidth, 0x3F);				//	RegModWidth
		WriteRawRC(RegModWidthSOF, 0x3F);			//	RegModWidthSOF
	//	WriteRawRC(RegTypeBFraming, 0x40);			//	RegTypeBFraming

		//page3
		WriteRawRC(RegPage, 0x83);
		WriteRawRC(RegRxControl1, 0x8B);			//	RegRxControl1
		WriteRawRC(RegDecoderControl, 0x34);		//	RegDecoderControl
		WriteRawRC(RegBitPhase, 0xCD);				//	RegBitPhase
		WriteRawRC(RegRxThreshold, 0x88);			//	RegRxThreshold
		WriteRawRC(RegBPSKDemControl, 0x00);		//	RegBPSKDemControl
		WriteRawRC(RegRxControl2, 0x01);			//	RegRxControl2
		WriteRawRC(RegClockQControl, 0x00);			//	RegClockQControl

		//page4
		WriteRawRC(RegPage, 0x84);
		WriteRawRC(RegRxWait, 0x08);				//	RegRxWait
		WriteRawRC(RegChannelRedundancy, 0x2C);		//	RegChannelRedundancy
		WriteRawRC(RegCRCPresetLSB, 0xFF);			//	RegCRCPresetLSB
		WriteRawRC(RegCRCPresetMSB, 0xFF);			//	RegCRCPresetMSB
		WriteRawRC(RegTimeSlotPeriod, 0x00);		//	RegTimeSlotPeriod
		WriteRawRC(RegMfOutSelect, MFoutValue);			//	RegMfOutSelect
		//WriteRawRC(0x27, 0x00);					//	

		//page5
		WriteRawRC(RegPage, 0x85);
		WriteRawRC(RegFIFOLevel, 0x3E);				//	RegFIFOLevel
		WriteRawRC(RegTimerClock, 0x0B);			//	RegTimerClock
		WriteRawRC(RegTimerControl, 0x06);			//	RegTimerControl
		WriteRawRC(RegTimerReload, 0x00);			//	RegTimerReload
		WriteRawRC(RegIRqPinConfig, 0x00);			//	RegIRqPinConfig
		//WriteRawRC(0x2E, 0x00);					//	
		//WriteRawRC(0x2F, 0x00);					//

	return MI_OK;
}
/*****************************************************************************
*ԭ�ͣ�unsigned char ISO15693_Inventory(unsigned char Flags, 
								 unsigned char AFI,
								 unsigned char Mask_Length, 
								 unsigned char *Mask,
								 unsigned char *pReceiveLength, 
								 unsigned char *pReceiveData)
*���ܣ�ִ��Inventory����,�õ����صĿ���UID
*input: Flags
		AFI
		Mask_Length
		*Mask
*output: status
*****************************************************************************/
unsigned char ISO15693_Inventory(unsigned char Flags, 
								 unsigned char AFI,
								 unsigned char Mask_Length, 
								 unsigned char *Mask,
								 unsigned char *pReceiveLength, 
								 unsigned char *pReceiveData)
{
	unsigned char Index, ByteCnt;
	unsigned char status;
	unsigned char i;
   TranSciveBuffer MfComData;
	TranSciveBuffer *pi;
  
	pi=&MfComData;

	MfComData.MfCommand = PCD_TRANSCEIVE;

	MfComData.MfData[0] = Flags; //Flag
	MfComData.MfData[1] = ISO15693_INVENTORY;  //Command
	Index = 2;
	if((Flags&0x10) != 0x00)//�ж��Ƿ�����AFI
	{
		MfComData.MfData[Index++] = AFI;
	}
	MfComData.MfData[Index++] = Mask_Length;
	
	if (Mask_Length%8)
	{
		ByteCnt = Mask_Length/8 + 1;
	}
	else
	{
		ByteCnt = Mask_Length/8;
	}
	if(ByteCnt)
	{
		memcpy (&(MfComData.MfData[Index]), Mask, ByteCnt);	
		Index += ByteCnt;
	}
	
    MfComData.MfLength = Index;
	if((Flags&0x20) != 0x00) //Only use 1 slot to inventory
	{
		status = PcdComTransceive(pi);
	}
	*pReceiveLength = 0;
	if (status == 0)
	{
		unsigned char j = MfComData.MfLength / 8;
		if (MfComData.MfData[0] & 0x01 == 1)
		{
			status = 0xFF;
		}
		else
		{
			for (i=0; i<j; i++)
			{
				pReceiveData[i] = MfComData.MfData[i];
			}
			*pReceiveLength = j;
		}
	}
	return  status;
}

/*****************************************************************************
*ԭ�ͣ�unsigned char ISO15693_ReadBlock(unsigned char Flags, 
								 unsigned char *UID, 
                            	 unsigned char BlockNumber, 
                            	 unsigned char NumberOfBlock,
					   			 unsigned char *pReceiveLength, 
					   			 unsigned char *pReceiveData)
*���ܣ�ִ��ReadBlock����,�õ����ص�����
*input: Flags			ѡ��
		*UID			��UID
		BlockNumber		���
		NumberOfBlock	������
*output: status
*****************************************************************************/
unsigned char ISO15693_ReadBlock(unsigned char Flags, 
								 unsigned char *UID, 
                            	 unsigned char BlockNumber, 
                            	 unsigned char NumberOfBlock,
					   			 unsigned char *pReceiveLength, 
					   			 unsigned char *pReceiveData)
{
	unsigned char status;
	unsigned char i;
	unsigned char Index;
	TranSciveBuffer MfComData;
	TranSciveBuffer *pi;

	pi=&MfComData;


	if (NumberOfBlock > 0)
	{
		NumberOfBlock--;
	}
	MfComData.MfCommand = PCD_TRANSCEIVE;
	MfComData.MfData[0] = Flags;
	if (NumberOfBlock > 0)
	{
		MfComData.MfData[1] = ISO15693_READ_MULTIPLE_BLOCK;  	//Command
	}
	else
	{
		MfComData.MfData[1] = ISO15693_READ_SINGLE_BLOCK;   	//Command
	}
	Index = 2;
	if (Flags & 0x20) 	// flags & 0x20 - Adresflag request 
						// flags & 0x10 - Selectflag request			  		
	{
		for (i=0; i<8; i++)
		{
			MfComData.MfData[Index++] = UID[i];
		}
	}
	MfComData.MfData[Index++] = BlockNumber;
	if (NumberOfBlock > 0)
	{
		MfComData.MfData[Index++] = NumberOfBlock;
	}
	MfComData.MfLength = Index;
	status = PcdComTransceive(pi);
	*pReceiveLength = 0;
	if (status == 0)
	{
		unsigned char j = MfComData.MfLength / 8;
		if (MfComData.MfData[0] & 0x01 == 1)
		{
			status = 0xFF;
		}
		else
		{
			for (i=0; i<j; i++)
			{
				pReceiveData[i] = MfComData.MfData[i];
			}
			*pReceiveLength = j;
		}
	}
	return  status;
}

/*****************************************************************************
*ԭ�ͣ�unsigned char ISO15693_WriteBlock(unsigned char Flags, 
							 unsigned char *UID, 
							 unsigned char BlockNumber,
							 unsigned char NumberOfBlock,
							 unsigned char *pWriteData, 
							 unsigned char *pReceiveLength,
							 unsigned char *pReceiveData)
*���ܣ�ִ��WriteBlock����
*input: Flags			ѡ��
		*UID			��UID
		BlockNumber		���
		NumberOfBlock	������
		*pWriteData		Ҫд�뿨������
*output: status
*****************************************************************************/
unsigned char ISO15693_WriteBlock(unsigned char Flags, 
							 unsigned char *UID, 
							 unsigned char BlockNumber,
							 unsigned char NumberOfBlock,
							 unsigned char *pWriteData, 
							 unsigned char *pReceiveLength,
							 unsigned char *pReceiveData)
{
	unsigned char status;
	unsigned char i;
	unsigned char Index;
	TranSciveBuffer MfComData;
	TranSciveBuffer *pi;

	pi=&MfComData;

	if (NumberOfBlock > 0)
	{
		NumberOfBlock--;
	}

	if (Flags & 0x40)
	{
		MfComData.MfCommand = PCD_TRANSMIT;
	}
	else
	{
		MfComData.MfCommand = PCD_TRANSCEIVE;
	}

	MfComData.MfData[0] = Flags;
	if (NumberOfBlock > 0)
	{
		MfComData.MfData[1] = ISO15693_WRITE_MULTIPLE_BLOCK;  //Command
	}
	else
	{
		MfComData.MfData[1] = ISO15693_WRITE_SINGLE_BLOCK;  //Command
	}
	Index = 2;
	if (Flags & 0x20)	// flags & 0x20 - Adresflag request 
						// flags & 0x10 - Selectflag request
	{
		for (i=0; i<8; i++)
		{
			MfComData.MfData[Index++] = UID[i];
		}
	}
	MfComData.MfData[Index++] = BlockNumber;
	for (i=0; i<4*(NumberOfBlock+1); i++)
	{
		MfComData.MfData[Index++] = pWriteData[i];
	}
	MfComData.MfLength = Index;
	status = PcdComTransceive(pi);
	if (status == 0)
	{
		if ((Flags & 0x40) == 0)
		{
			if (MfComData.MfData[0] & 0x01 == 1)
			{
				status = 0xFF;
			}
		}
		else
		{
			DelayMs(100);
			SetBitMask(RegCoderControl, 0x80);
			MfComData.MfCommand = PCD_TRANSCEIVE;
			MfComData.MfLength = Index;// 0;
			status = PcdComTransceive(pi);
			ClearBitMask(RegCoderControl, 0x80);
			if (status  == 0)
			{
				if (MfComData.MfData[0] & 0x01 == 1)
				{
					status = 0xFF;
				}
			}
		}
	}
	*pReceiveLength = 0;
	return  status;
}

/*****************************************************************************
*ԭ�ͣ�unsigned char ISO15693_ResetToReady(unsigned char Flags,  
                         	  unsigned char *UID,
                         	  unsigned char *pReceiveLength,   
                         	  unsigned char *pReceiveData) 
*���ܣ�ִ��ResetToReady����
*input: Flags			ѡ��
		*UID			��UID
		AFI				AFI����
*output: status
*****************************************************************************/ 
unsigned char ISO15693_WriteAFI(unsigned char Flags,  
                         		 unsigned char *UID,  
                         		 unsigned char AFI, 
                         		 unsigned char *pReceiveLength,   
                         		 unsigned char *pReceiveData) 
{ 
	unsigned char status;
	unsigned char i;
	unsigned char Index;
	TranSciveBuffer MfComData;
	TranSciveBuffer *pi;

	pi=&MfComData;
	if (Flags & 0x40)
	{
		MfComData.MfCommand = PCD_TRANSMIT;
	}
	else
	{
		MfComData.MfCommand = PCD_TRANSCEIVE;
	}

	MfComData.MfData[0] = Flags;
	MfComData.MfData[1] = ISO15693_WRITE_AFI;  //Command
	
	Index = 2;
	if ((Flags & 0x20))	// flags & 0x20 - Adresflag request 
						// flags & 0x10 - Selectflag request
	{
		for (i=0; i<8; i++)
		{
			MfComData.MfData[Index++] = UID[i];
		}
	}
	MfComData.MfData[Index++] = AFI;
	MfComData.MfLength = Index;
	status = PcdComTransceive(pi);
	*pReceiveLength = 0;
	if (status == 0)
	{
		unsigned char j = MfComData.MfLength / 8;
		if (MfComData.MfData[0] & 0x01 == 1)
		{
			status = 0xFF;	  			
		}
		else
		{
			for (i=0; i<j; i++)
			{
				pReceiveData[i] = MfComData.MfData[i];
			}
			*pReceiveLength = j;
		}
	}
	return  status;
} 



unsigned char ISO15693_LockAFI(unsigned char Flags,  
                         	  unsigned char *UID,  
                         	  unsigned char *pReceiveLength,   
                         	  unsigned char *pReceiveData) 
{ 
	unsigned char status;
	unsigned char i;
	unsigned char Index;
	TranSciveBuffer MfComData;
	TranSciveBuffer *pi;

	pi=&MfComData;
	//MfComData.MfCommand = PCD_TRANSCEIVE;
	if (Flags & 0x40)
	{
		MfComData.MfCommand = PCD_TRANSMIT;
	}
	else
	{
		MfComData.MfCommand = PCD_TRANSCEIVE;
	}
	MfComData.MfData[0] = Flags; 
	MfComData.MfData[1] = ISO15693_LOCK_AFI;  //Command
	
	Index = 2;
	if ((Flags & 0x20))	// flags & 0x20 - Adresflag request 
						// flags & 0x10 - Selectflag request
	{
		for (i=0; i<8; i++)
		{
			MfComData.MfData[Index++] = UID[i];
		}
	}
	
	MfComData.MfLength = Index;
	status = PcdComTransceive(pi);
	*pReceiveLength = 0;
	if (status == 0)
	{
		unsigned char j = MfComData.MfLength / 8;
		if (MfComData.MfData[0] & 0x01 == 1)
		{
			status = 0xFF;
		}
		else
		{
			for (i=0; i<j; i++)
			{
				pReceiveData[i] = MfComData.MfData[i];
			}
			*pReceiveLength = j;
		}
	}
	return  status;
} 

/*****************************************************************************
*ԭ�ͣ�unsigned char ISO15693_WriteDSFID(unsigned char Flags,  
                         		 unsigned char *UID,  
                         		 unsigned char DSFID, 
                         		 unsigned char *pReceiveLength,   
                         		 unsigned char *pReceiveData)  
*���ܣ�ִ��WriteDSFID����
*input: Flags			ѡ��
		*UID			��UID
		DSFID			DSFID����
*output: status
*****************************************************************************/
unsigned char ISO15693_WriteDSFID(unsigned char Flags,  
                         		 unsigned char *UID,  
                         		 unsigned char DSFID, 
                         		 unsigned char *pReceiveLength,   
                         		 unsigned char *pReceiveData) 
{ 
	unsigned char status;
	unsigned char i;
	unsigned char Index;
	TranSciveBuffer MfComData;
	TranSciveBuffer *pi;

	pi=&MfComData;

	if (Flags & 0x40)
	{
		MfComData.MfCommand = PCD_TRANSMIT;
	}
	else
	{
		MfComData.MfCommand = PCD_TRANSCEIVE;
	}

	MfComData.MfData[0] = Flags;
	MfComData.MfData[1] = ISO15693_WRITE_DSFID;  //Command
	
	Index = 2;
	if ((Flags & 0x20))	// flags & 0x20 - Adresflag request 
						// flags & 0x10 - Selectflag request
	{
		for (i=0; i<8; i++)
		{
			MfComData.MfData[Index++] = UID[i];
		}
	}
	MfComData.MfData[Index++] = DSFID;
	MfComData.MfLength = Index;
	status = PcdComTransceive(pi);
	*pReceiveLength = 0;
	if (status == 0)
	{
		unsigned char j = MfComData.MfLength / 8;
		if (MfComData.MfData[0] & 0x01 == 1)
		{
			status = 0xFF;
		}
		else
		{
			for (i=0; i<j; i++)
			{
				pReceiveData[i] = MfComData.MfData[i];
			}
			*pReceiveLength = j;
		}
	}
	return  status;
} 


/*****************************************************************************
*ԭ�ͣ�unsigned char ISO15693_LockDSFID(unsigned char Flags,  
                         	  unsigned char *UID,  
                         	  unsigned char *pReceiveLength,   
                         	  unsigned char *pReceiveData)  
*���ܣ�ִ��LockDSFID����
*input: Flags			ѡ��
		*UID			��UID
*output: status
*****************************************************************************/
unsigned char ISO15693_LockDSFID(unsigned char Flags,  
                         	  unsigned char *UID,  
                         	  unsigned char *pReceiveLength,   
                         	  unsigned char *pReceiveData) 
{ 
	unsigned char status;
	unsigned char i;
	unsigned char Index;
	TranSciveBuffer MfComData;
	TranSciveBuffer *pi;

	pi=&MfComData;
	//MfComData.MfCommand = PCD_TRANSCEIVE;
	if (Flags & 0x40)
	{
		MfComData.MfCommand = PCD_TRANSMIT;
		//MfComData.MfCommand = PCD_TRANSCEIVE;
	}
	else
	{
		MfComData.MfCommand = PCD_TRANSCEIVE;
	}
	MfComData.MfData[0] = Flags; //Flag
	MfComData.MfData[1] = ISO15693_LOCK_DSFID;  //Command
	
	Index = 2;
	if ((Flags & 0x20))	// flags & 0x20 - Adresflag request flags & 
						// 0x10 - Selectflag request
	{
		for (i=0; i<8; i++)
		{
			MfComData.MfData[Index++] = UID[i];
		}
	}
	
	MfComData.MfLength = Index;// + 1;
	status = PcdComTransceive(pi);
	*pReceiveLength = 0;
	if (status == 0)
	{
		unsigned char j = MfComData.MfLength / 8;
		if (MfComData.MfData[0] & 0x01 == 1)
		{
			status = 0xFF;
		}
		else
		{
			for (i=0; i<j; i++)
			{
				pReceiveData[i] = MfComData.MfData[i];
			}
			*pReceiveLength = j;
		}
	}
	return  status;
} 

/*****************************************************************************
*ԭ�ͣ�unsigned char ISO15693_GetMultipleBlockSecurity(unsigned char Flags, 
								 unsigned char *UID, 
                            	 unsigned char BlockNumber, 
                            	 unsigned char NumberOfBlock,
					   			 unsigned char *pReceiveLength, 
					   			 unsigned char *pReceiveData)
*���ܣ�ִ��GetMultipleBlockSecurity����,�õ����ص�����
*input: Flags			ѡ��
		*UID			��UID
		BlockNumber		���
		NumberOfBlock	������
*output: status
*****************************************************************************/
unsigned char ISO15693_GetMultipleBlockSecurity(unsigned char Flags, 
								 unsigned char *UID, 
                            	 unsigned char BlockNumber, 
                            	 unsigned char NumberOfBlock,
					   			 unsigned char *pReceiveLength, 
					   			 unsigned char *pReceiveData)
{
	unsigned char status;
	unsigned char i;
	unsigned char Index;
	TranSciveBuffer MfComData;
	TranSciveBuffer *pi;

	pi=&MfComData;


	if (NumberOfBlock > 0)
	{
		NumberOfBlock--;
	}
	MfComData.MfCommand = PCD_TRANSCEIVE;
	MfComData.MfData[0] = Flags; 
	MfComData.MfData[1] = ISO15693_GET_MULTIPLE_BLOCK_SECURITY_STATUS;  //Command
	
	Index = 2;
	if (Flags & 0x20) 	// flags & 0x20 - Adresflag request flags & 
			  			// flags & 0x10 - Selectflag request
	{
		for (i=0; i<8; i++)
		{
			MfComData.MfData[Index++] = UID[i];
		}
	}
	MfComData.MfData[Index++] = BlockNumber;
	if (NumberOfBlock > 0)
	{
		MfComData.MfData[Index++] = NumberOfBlock;
	}
	MfComData.MfLength = Index;
	status = PcdComTransceive(pi);
	*pReceiveLength = 0;
	if (status == 0)
	{
		unsigned char j = MfComData.MfLength / 8;
		if (MfComData.MfData[0] & 0x01 == 1)
		{
			status = 0xFF;
		}
		else
		{
			for (i=0; i<j; i++)
			{
				pReceiveData[i] = MfComData.MfData[i];
			}
			*pReceiveLength = j;
		}
	}
	return  status;
}
