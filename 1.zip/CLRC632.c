#include "delay.h"
#include "CLRC632.h"
#include "rc500.h"
#include "usart.h"


unsigned char RC530_OK;                                 //RC500��λ������־
extern unsigned char WhichUSART_SearchCard ;         //��һ�����ڷ���Ѱ��ָ�0x00�� û��ָ��   0x01��USART1��ָ��




/*****************************************************************************
* ��������void Rc500Ready()
 *���� ����ǩ�Ķ����ĳ�ʼ��	��ע��:RC500�ϵ��Ӧ��ʱ500ms���ܿɿ���ʼ��
* ������ ��
*����ֵ����
*****************************************************************************/
void Rc500Ready(void)
{
    signed char status = MI_OK;
    DelayMs(100);
    DelayMs(100);
    DelayMs(100);
    DelayMs(100);
    DelayMs(100);
    status=PcdReset();
    if(status!=MI_OK)
    {
         DelayMs(100);
        status=PcdReset();
    }
    if(status==MI_OK)
	{
        RC530_OK=1;
	}
    else
	{
        RC530_OK=0;
	}
}

uint ConverByteTOASCII(unsigned char Src)
{
   unsigned char SrcData = Src;
   unsigned char buffer[2];
   unsigned int result;
         //ȡ����λ 	 	
          buffer[0] = (SrcData & 0xf0)>> 4;   //ȡ����λ
	      buffer[1] = SrcData & 0x0f;   
	
		  //*****************����λת��************************************** 
		   if((buffer[0]>=0)  && (buffer[0]<= 9))
			  {	  buffer[0] += 0x30 ; }					     	  					  
		   else
		      if( buffer[0]>= 0x0A && buffer[0]<= 0x0F)
			     {
					   	 switch(buffer[0])
						   {
						       case 0x0a:buffer[0] = 0x41;break;	  // A
						   	   case 0x0b:buffer[0] = 0x42;break;	  // B
							   case 0x0c:buffer[0] = 0x43;break;	  // c
							   case 0x0d:buffer[0] = 0x44;break;	  // d
							   case 0x0e:buffer[0] = 0x45;break;	  // e
							   case 0x0f:buffer[0] = 0x46;break;	  // f
							   default:break;
						   }		 
				 }
		 //******************* ����λת�� **********************************************
		      if(buffer[1]>=0x00  && buffer[1]<= 0x09)
			    {  buffer[1] += 0x30 ; 	}  
		      else
			      if( buffer[1]>= 0x0A && buffer[1]<= 0x0F)
				     {
					   	 switch(buffer[1])
						   {
						       case 0x0a:buffer[1] = 0x41;break;	  // A
						   	   case 0x0b:buffer[1] = 0x42;break;	  // B
							   case 0x0c:buffer[1] = 0x43;break;	  // c
							   case 0x0d:buffer[1] = 0x44;break;	  // d
							   case 0x0e:buffer[1] = 0x45;break;	  // e
							   case 0x0f:buffer[1] = 0x46;break;	  // f
							   default:break;
						   }
			          }
			   //*****************����ת����ֵ******************************************************
		
		   result = buffer[0];
		   result = (result<<8)| buffer[1];		 
	return  result;		
}
void SendStr(unsigned char *Str,unsigned char StrLenth)
{
	while( StrLenth-- )
		{
			SendByte(*Str++);
		}
}


void SendByte(unsigned char i)
{ 
   switch(WhichUSART_SearchCard)
      {
	  	 case 0x01: USART1_Putc(i); break;
		 default:   break;
	  }

}

